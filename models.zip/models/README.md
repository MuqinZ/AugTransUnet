# TransBTS（MICCAI2021）& TransBTSV2 (To Be Updated)

This repo is the official implementation for: 
1) [TransBTS: Multimodal Brain Tumor Segmentation Using Transformer](https://arxiv.org/pdf/2103.04430.pdf). 

2) [TransBTSV2: Towards Better and More Efficient Volumetric Segmentation of Medical Images](https://arxiv.org/abs/2201.12785). 

The details of the our TransBTS and TransBTSV2 can be found in the following directory or in the original paper.
